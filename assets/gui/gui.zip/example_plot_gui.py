"""
Created on 27.05.2025

@author: Romain Tirole
         The Advanced Science Research Center, City University of New York
         rtirole1@gc.cuny.edu
"""

import numpy as np

import pyqtgraph as pg

import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSizePolicy

class PlotWidget(QWidget):
    
    def __init__(self):
        
        # let's say we just want to show some data, a gaussian for example
        self.x = np.linspace(-50, 50, 301)
        self.y = np.exp(-self.x**2/8)
        
        # just get the Qt out of it
        super().__init__()
        
        # layout
        self.central_layout = QHBoxLayout(self)
        self.matplotlibWidget = QWidget()
        self.matplotlibLayout = QVBoxLayout(self.matplotlibWidget)
        self.pyqtgraphWidget = QWidget()
        self.pyqtgraphLayout = QVBoxLayout(self.pyqtgraphWidget)
        self.central_layout.addWidget(self.matplotlibWidget)
        self.central_layout.addWidget(self.pyqtgraphWidget)
        
        # Matplotlib version
        
        self.mpFig = Figure(tight_layout=True)#Figure(figsize=(width, height), dpi=dpi, facecolor="white")
        self.mpFigCanvas = FigureCanvas(self.mpFig)
        self.mpax = self.mpFig.add_subplot()
        self.mpFigCanvas.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.matplotlibLayout.addWidget(self.mpFigCanvas)
        self.navigationToolbar = NavigationToolbar(self.mpFigCanvas)
        self.matplotlibLayout.addWidget(self.navigationToolbar)
        
        self.p, = self.mpax.plot([0], [0])
        self.mpax.set_xlabel('x', fontsize=14)
        self.mpax.set_ylabel('y', fontsize=14)
        self.mpax.set_xlim(min(self.x), max(self.x))
        self.mpax.set_title('Matplotlib', fontsize=14)
        self.mpax.tick_params(axis='both', which='major', labelsize=10)

        # PyQtGraph version
        
        self.pyqtCanvas = pg.PlotWidget(title='PyQtGraph')
        self.pyqtgraphLayout.addWidget(self.pyqtCanvas)
        self.pen = pg.mkPen(color='b', width=2)
        self.pqtplot = self.pyqtCanvas.plot([0], [0], pen=self.pen)
        
        self.styles = {'color':'k', 'font-size':'14pt'}
        self.pyqtCanvas.setLabel('left', 'y', **self.styles)
        self.pyqtCanvas.setLabel('bottom', 'x', **self.styles)
        self.pyqtCanvas.setBackground('w')
        self.pyqtCanvas.showGrid(x=True, y=True)
        self.pyqtCanvas.enableAutoRange(axis='y')
        self.pyqtCanvas.enableAutoRange(axis='x')
        self.pyqtCanvas.setAutoVisible(y=True)
        
        # methods to change the data in the matplotlib plot
        self.p.set_data(self.x, self.y)
        self.mpax.set_xlim(min(self.x), max(self.x))
        self.mpax.set_ylim(0, 1.1)
        
        # methods to change the data in the pyqtgraph plot
        self.pqtplot.setData(self.x, self.y, pen=self.pen)
        self.pyqtCanvas.setXRange(min(self.x), max(self.x))
        self.pyqtCanvas.setYRange(0, 1.1)
        
class PlotGui(QMainWindow):
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()
        
        # title
        self.setWindowTitle('Matplotlib vs PyQtGraph')
        
        # create the motor widget
        self.plotWidget = PlotWidget()
        
        # make the motor widget the central widget
        self.setCentralWidget(self.plotWidget)
        
        # running the window
        self.show()
        
if __name__ == '__main__':
    myPlot = PlotGui()