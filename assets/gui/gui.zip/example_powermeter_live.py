"""
Created on 29.03.2024

@author: Romain Tirole
         The Advanced Science Research Center, City University of New York
         rtirole1@gc.cuny.edu
"""

import pyvisa
from ThorlabsPM100 import ThorlabsPM100
import numpy as np

# NB: here we use pyqtgraph, but you can change comments to use the matplotlib implementation instead
import pyqtgraph as pg

# import matplotlib
# matplotlib.use("Qt5Agg")
# from matplotlib.figure import Figure
# from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
# from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

from PyQt5.QtCore import QObject, QThread, pyqtSignal, QTimer
from PyQt5.QtWidgets import QMainWindow, QWidget
from PyQt5 import uic

# just a module to have more information if there is a bug in the code
from sys import exc_info

class Powermeter:
    
    def __init__(self):

        # note: depending on your device you may need to specify the backend of your pyvisa module
        # self.rm = pyvisa.ResourceManager('@py')
        self.rm = pyvisa.ResourceManager()
        self.powermeters = None
        self.inst = None
        self.pm = None
        self.lastAcq = None
        self.wl = None
        self.unit = None
        self.bcg = 0
        self.trace = np.zeros(100)
        
    def find_powermeter(self):
        self.powermeters = {}
        for addr in self.rm.list_resources():
            try:
                name = self.rm.open_resource(addr).query('*IDN?')
                if 'PM100' in name:
                    self.powermeters[name] = addr
            except:
                pass
    
    def connect(self, REF):
        self.inst = self.rm.open_resource(self.powermeters[REF])
        self.inst.read_termination = '\n'
        self.inst.write_termination = '\r\n'
        self.pm = ThorlabsPM100(inst=self.inst)
        self.pm.configure.scalar.power()
        self.lastAcq = self.pm.read
        self.wl = self.inst.query('sense:corr:wav?')
        self.unit = self.pm.sense.power.dc.unit
        print('Connected to powermeter: ' + REF)
        
    def read(self, pure=False):
        if pure:
            val = self.pm.read
        else:
            val = self.pm.read - self.bcg
        self.lastAcq = val
        self.trace = np.append(self.trace[1:], val)
        return val
    
    def get_background(self):
        self.bcg = self.read(pure=True)
        self.read()
    
    def get_wavelength(self):
        wl = self.inst.query('sense:corr:wav?')
        self.wl = wl
        return wl
    
    def set_wavelength(self, wl):
        self.inst.write('sense:corr:wav '+str(int(wl)))
        self.wl = self.inst.query('sense:corr:wav?')
        
    def switch_unit(self):
        if self.unit == 'W':
            self.inst.write('power:dc:unit dBm')
            self.unit = self.pm.sense.power.dc.unit
        else:
            self.inst.write('power:dc:unit W')
            self.unit = self.pm.sense.power.dc.unit
            
class LiveWorker(QObject):
    
    # PyQt Signals
    live_plot_update = pyqtSignal(np.ndarray)
    end_of_run = pyqtSignal() # happens many times a second
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()
    
    def add_parent(self, parent):
        self.parent = parent
        self.prev_array = np.zeros(100)

    # Main loop
    def run(self):
        try:
            self.parent.pm.read()
            self.array = self.parent.pm.trace.copy()
            self.prev_array = self.array.copy()
        except Exception as e:
            print('Error on line {}'.format(exc_info()[-1].tb_lineno), type(e).__name__, e)
            print(e)
            self.parent.isLiveBox.setChecked(False)
            self.array = self.prev_array
        
        self.live_plot_update.emit(self.array) # send the array back to the widget
        self.end_of_run.emit() # emit the signal to keep the loop going
            
class PowermeterWidget(QWidget):
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()
        
        uic.loadUi('Uis/example_powermeter_widget.ui', self)
        
        # initialise powermeter object
        self.pm = Powermeter()
        self.pm.find_powermeter()
        self.refreshRate = self.refreshRateSlider.value()
        
        # find powermeters
        for powermeter in self.pm.powermeters:
            self.dropDown.addItem(powermeter)
        self.connectButton.clicked.connect(self.connect)
        
        # NB: here I also give in comment an implementation of the matplotlib live plotting option
        
        # # trace canvas
        # self.traceFig = Figure(tight_layout=True)#Figure(figsize=(width, height), dpi=dpi, facecolor="white")
        # self.traceFigureCanvas = FigureCanvas(self.traceFig)
        # self.traceAx = self.traceFig.add_subplot()
        # self.traceFigureCanvas.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        # self.traceCanvasWidget_layout.addWidget(self.traceFigureCanvas)
        # self.navigationToolbar = NavigationToolbar(self.traceFigureCanvas)
        # self.traceCanvasWidget_layout.addWidget(self.navigationToolbar)
        
        # # set up plot
        # self.p, = self.traceAx.plot(np.arange(100)+1, np.zeros(100))
        # self.traceAx.set_xlabel('Trace number', fontsize=14)
        # self.traceAx.set_ylabel('Power (unit)', fontsize=14)
        # self.traceAx.set_xlim(1, 100)
        # self.traceAx.set_title('Powermeter trace', fontsize=14)
        # self.traceAx.tick_params(axis='both', which='major', labelsize=10)

        # trace canvas
        self.traceCanvas = pg.PlotWidget(title='Trace: power')
        self.traceCanvasWidget_layout.addWidget(self.traceCanvas)
        self.trace = self.traceCanvas.plot([0],[0])
        
        self.styles = {'color':'k', 'font-size':'14pt'}
        self.traceCanvas.setLabel('left', 'Power (unit)', **self.styles)
        self.traceCanvas.setLabel('bottom', 'Trace', **self.styles)
        
        self.pen = pg.mkPen(color='b', width=2)
        self.traceCanvas.setBackground('w')
        self.traceCanvas.setLabel('left', 'Integrated Counts', **self.styles)
        self.traceCanvas.setLabel('bottom', '', **self.styles)
        self.traceCanvas.showGrid(x=True, y=True)
        self.traceCanvas.enableAutoRange(axis='y')
        self.traceCanvas.enableAutoRange(axis='x')
        self.traceCanvas.setAutoVisible(y=True)
        
        # acquisition button
        self.acqButton.clicked.connect(self.acquire)
        
        # set wavelength button
        self.wlButton.clicked.connect(self.change_wavelength)
        
        # change unit
        self.unitButton.clicked.connect(self.switch_unit)
        
        # background
        self.bcgButton.clicked.connect(self.take_background)
        
        # refresh rate
        self.refreshRateSlider.valueChanged.connect(self.change_refresh_rate)
        
        # live view
        self.isLiveBox.stateChanged.connect(self.checked)
        
        # threading control
        self.stopThread = False
        
        # ready for live viewing
        self.load_thread()
        
    def load_thread(self):
        self.thread = QThread()
        self.thread.setObjectName('Powermeter_Thread') # so we can see it in htop, note you have to hit F2 -> Display options -> Show custom thread names
        self.worker = LiveWorker()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.add_parent(self)
        self.worker.live_plot_update.connect(self.refresh)
        self.worker.end_of_run.connect(self.end_of_run_callback)
        self.thread.finished.connect(self.thread_finished)
        
    def end_of_run_callback(self):
        if self.isLiveBox.isChecked():
            QTimer.singleShot(self.refreshRate, self.worker.run) # Run worker again immediately
        else:
            self.thread.quit()
            self.thread.wait()
    
    def thread_finished(self):
        self.worker.deleteLater()
        self.thread.deleteLater()
        self.load_thread()
        
    def checked(self):
        if self.isLiveBox.isChecked():
            self.start_live()
        
    def start_live(self):
        self.thread.start()
        
    def connect(self):
        self.pm.connect(self.dropDown.currentText())
        self.isLiveBox.setChecked(True)
        self.start_live()
            
    def refresh(self, array):
        self.trace.setData(np.arange(100)+1, array, pen=self.pen)
        self.traceCanvas.setXRange(0, 100) 
        self.traceCanvas.setYRange(min([1.05*min(array), 0]), max([1.05*max(array), 0])) 
        #self.traceCanvas.enableAutoRange(axis='y')
        self.traceCanvas.setAutoVisible(y=True)
        self.powerLabel.setText('{:.2e}'.format(array[-1]) + ' ' + self.pm.unit)
        # self.p.set_data(np.arange(100)+1, self.pm.trace)
        # self.traceAx.autoscale()
        # self.traceAx.relim()
        # self.traceAx.set_xlim(1, 100)
        # self.traceFigureCanvas.draw()
            
    def take_background(self):
        self.isLiveBox.setChecked(False)
        self.pm.get_background()
        
    def change_refresh_rate(self):
        self.refreshRate = self.refreshRateSlider.value()
        self.refreshRateLabel.setText("Refresh rate: {rate} ms".format(rate=self.refreshRate))
        
    def acquire(self):
        _ = self.pm.read()
        self.acqLabel.setText('{:.2e}'.format(self.pm.trace[-1]) + ' ' + self.pm.unit)
        
    def change_wavelength(self):
        self.pm.set_wavelength((int(self.wlInput.text())))
        wl = self.pm.get_wavelength()
        self.wlLabel.setText('{:.2e}'.format(wl)+' nm')
        
    def switch_unit(self):
        self.pm.switch_unit()
        self.traceAx.set_ylabel('Power (' + self.pm.unit + ')', fontsize=14)
        
    def close(self, *args, **kwargs):
        try:
            self.isLiveBox.setChecked(False)
        except:
            pass
        super(QWidget, self).close(*args, **kwargs)
        
class PowermeterGui(QMainWindow):
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()
        
        # title
        self.setWindowTitle('Powermeter')
        
        # create the motor widget
        self.powermeterWidget = PowermeterWidget()
        
        # make the motor widget the central widget
        self.setCentralWidget(self.powermeterWidget)
        
        # running the window
        self.show()
        
    def closeEvent(self, *args, **kwargs):
        try:
            self.PowerWidget.close()
        except:
            pass
        super(QMainWindow, self).closeEvent(*args, **kwargs)
        
if __name__ == '__main__':
    myPowermeter = PowermeterGui()