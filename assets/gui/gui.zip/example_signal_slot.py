import numpy as np
from time import sleep
import pyqtgraph as pg
from PyQt5.QtCore import QObject, QThread, pyqtSignal, QTimer
from PyQt5.QtWidgets import (QMainWindow, 
                             QFileDialog, 
                             QWidget, 
                             QSlider, 
                             QMessageBox)
from datetime import datetime
from PyQt5 import uic
from sys import exc_info


class LiveWorker(QObject):
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()

        # PyQt Signals
        self.live_plot_update = pyqtSignal(np.ndarray)
        self.end_of_run = pyqtSignal() # happens many times a second
    
    def add_parent(self, parent_widget):
        self.parent_widget = parent_widget

    def run(self):
        self.array = self.parent.instrument.measure()
        self.live_plot_update.emit(self.array) # send the array back to the widget
        self.end_of_run.emit() # emit the signal to let know your worker has finished working
        
class LiveWidget(QWidget):
    
    def __init__(self):
        
        [ALL THE USUAL WIDGET DEFINITION]
        
        # live view
        self.isLiveBox.stateChanged.connect(self.checked)
        
        # threading control
        self.stopThread = False
        
        # ready for live viewing
        self.load_thread()
        
    def load_thread(self):
        
        self.thread = QThread()
        self.thread.setObjectName('Thread')
        self.worker = LiveWorker()
        self.worker.moveToThread(self.thread) # create a separate thread for your worker
        self.thread.started.connect(self.worker.run) # when the thread starts, the worker will execute its main run function
        self.worker.add_parent(self) # connect the worker to the widget
        
        # slots
        self.worker.live_plot_update.connect(self.refresh) # when the worker emits a signal, this slot will pass it on to the refresh method!
        self.worker.end_of_run.connect(self.end_of_run_callback) # same here
        self.thread.finished.connect(self.thread_finished) # don't forget to wrap up the thread properly
        
    def end_of_run_callback(self): # the role of this function is to decide what to do once the thread has finished running
        if self.isLiveBox.isChecked():# Run worker again immediately if we're doing live viewing
            QTimer.singleShot(0, self.worker.run) 
        else: # if we don't want to anymore, we kill the thread
            self.thread.quit()
            self.thread.wait()
    
    def thread_finished(self): # this clears up the memory, and reloads the thread in case you want to run it again later
        self.worker.deleteLater()
        self.thread.deleteLater()
        self.load_thread()
        
    def checked(self): # this is called when you click the live view button
        if self.isLiveBox.isChecked():
            self.start_live()
        
    def start_live(self): # this starts the thread, which hapens when you click the live view button
        self.thread.start()
            
    def refresh(self, array): # here, the array is the one passed on by your worker signal!
        [function to update your graphs]