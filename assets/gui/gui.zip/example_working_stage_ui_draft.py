"""
@author: Romain Tirole
         The Advanced Science Research Center, City University of New York
         rtirole1@gc.cuny.edu
         
An example on how to load a stage and connect buttons and functions in an UI made in Qt Designer.
"""

# your own stage class to load
import Stage

# import the required PyQt5 functions
from PyQt5.QtWidgets import QMainWindow, QWidget
from PyQt5 import uic

class StageWidget(QWidget):
    
    def __init__(self):
        
        # create a stage object
        self.stage = Stage()
        
        # just get the Qt out of it
        super().__init__()
        
        # load the UI and assign it to the widget itself
        uic.loadUi('./Uis/example_stage_widget.ui', self)
        
        # when we create the widget, we want to look for available stages and list them as options
        self.stage.find_motors()
        for stage in self.stage.available_stages:
            self.drop_down.addItem(stage)
            
        # connect the move and connectbuttons in the widget to actual methods of either the stage of the widget
        self.connect_button.clicked.connect(self.connect_stage)
        
    def connect_stage(self):
        self.stage.set_stage(int(self.drop_down.currentText()))
        
    def closeEvent(self, *args, **kwargs):
        # this makes sure the affiliated stage instrument control disconnects properly when closing
        self.stage.on_closing()
        super(QWidget, self).closeEvent(*args, **kwargs)
        
class StageGui(QMainWindow):
    
    def __init__(self):
        
        # just get the Qt out of it
        super().__init__()
        
        # give a name to the window
        self.setWindowTitle('Stage')
        
        # create the affiliated stage widget
        self.stage_widget = StageWidget()
        
        # make the stage widget the main widget in the window
        self.setCentralWidget(self.stage_widget)
        
        # this runs the window once it is created
        self.show()
        
    def closeEvent(self, *args, **kwargs):
        # this makes sure the widgets within the Main Window are closing properly
        self.stageWidget.close()
        super(QMainWindow, self).closeEvent(*args, **kwargs)

if __name__ == '__main__':
    myStage = StageGui()